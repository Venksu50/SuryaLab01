import { Labour } from './labour';

describe('Labour', () => {
  it('should create an instance', () => {
    expect(new Labour()).toBeTruthy();
  });
});
